# -*- coding: utf-8 -*-
"""
Created on Tue Oct 10 18:26:54 2017

@author: batman
"""

import pandas as pd
import numpy as np
from sklearn.utils import class_weight
#from sklearn.model_selection import train_test_split
from sklearn import preprocessing

train=pd.read_csv("Data/churnTrainNew.csv")
test=pd.read_csv("Data/churnTestNew.csv")

#train.drop(["Id","phone_number"],axis=1,inplace=True)
#test.drop(["Id","phone_number","churn"],axis=1,inplace=True)
#
#
#### Label encoding state
#state_le = preprocessing.LabelEncoder()
#state_le.fit(train.state)
#train.state=state_le.transform(train.state)
#test.state=state_le.transform(test.state)   
#    
#### Label encoding area code
#area_le = preprocessing.LabelEncoder()
#area_le.fit(train.area_code)
#train.area_code=area_le.transform(train.area_code)
#test.area_code=area_le.transform(test.area_code)   

### Class Weight
class_weight = class_weight.compute_class_weight('balanced', np.unique(train.churn), train.churn)
class_weight_dict=dict(zip(np.unique(train.churn),class_weight))

y_train=train.churn.values
x_train=train.drop("churn",axis=1).values
testX=test.values


from sklearn.cross_validation import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from catboost import CatBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression

np.random.seed(0)  # seed to shuffle the train set

n_folds = 5
verbose = True
shuffle = False

X, y, X_submission = x_train, y_train, testX # Or use sklearn train test split to get numpy arrays


skf = list(StratifiedKFold(y, n_folds))

clfs = [RandomForestClassifier(n_estimators=100, n_jobs=-1, criterion='gini'),
        LogisticRegression(),
        
        ]

print ("Creating train and test sets for blending.")

dataset_blend_train = np.zeros((X.shape[0], len(clfs)))
dataset_blend_test = np.zeros((X_submission.shape[0], len(clfs)))

### Blending ensemble

for j, clf in enumerate(clfs): 
    print (j, clf)
    dataset_blend_test_j = np.zeros((X_submission.shape[0], len(skf)))
    for i, (train, test) in enumerate(skf):
        print ("Fold", i)
        X_train = X[train]
        y_train = y[train]
        X_test = X[test]
        y_test = y[test]
        clf.fit(X_train, y_train)
        y_submission = clf.predict_proba(X_test)[:, 1]
        dataset_blend_train[test, j] = y_submission
    clf.fit(X, y)
    dataset_blend_test[:, j] = clf.predict_proba(X_submission)[:, 1]


print ("Blending..........")
clf = LogisticRegression()
clf.fit(dataset_blend_train, y)
y_submission = clf.predict_proba(dataset_blend_test)[:, 1]

### Scoring
from sklearn.model_selection import cross_validate

scoring = {'acc': 'accuracy',
           'f1': 'f1',
           'precision': 'precision',
           'recall': 'recall',
           'roc_auc':'roc_auc'
           }

cv=5

scores = cross_validate(clf, dataset_blend_train, y, scoring=scoring,
                         cv=cv, return_train_score=True,n_jobs=-1)

avg_score={}
if 'score_time' in scores: del scores['score_time']
for metric_name in scores.keys():
    avg_score[metric_name] = np.average(scores[metric_name])



        
        

